import * as yup from 'yup'
export const ConferenceErrorSchema = yup.object().shape({
    // about: yup.string().required('Required Field'),
    // attendies: yup.string().required('Required Field'),
    // start_date_time: yup.string().required('Required Field'),
    // end_date_time: yup.string().required('Required Field'),
    // conf_room: yup.string().required('Required Field'),
    // r_plant_name: yup.string().required('Required Field'),
    // r_conf_room: yup.string().required('Required Field'),
})