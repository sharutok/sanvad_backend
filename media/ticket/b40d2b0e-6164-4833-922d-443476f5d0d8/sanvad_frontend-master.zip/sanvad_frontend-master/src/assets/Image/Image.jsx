const IMAGES = {
    ador_star_logo: new URL('../Image/Ador_Welding_logo_STAR.PNG', import.meta.url).href,
    ador_logo: new URL('../Image/AWL_logo_new.png', import.meta.url).href,
    yammer_alt: new URL('../Image/yammer_alt.jpg', import.meta.url).href,
    avatar_boy: new URL('../Image/boy.png', import.meta.url).href,
    avatar_girl: new URL('../Image/girl.png', import.meta.url).href,
    birthday_bg: new URL('../Image/girl.png', import.meta.url).href,
    login_img: new URL('../Image/Login Background.jpg', import.meta.url).href,
}

export default IMAGES