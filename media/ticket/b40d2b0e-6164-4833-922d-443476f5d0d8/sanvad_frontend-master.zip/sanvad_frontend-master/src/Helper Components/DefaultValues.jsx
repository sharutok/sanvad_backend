export default {
    app_name: {
        user_management_update_user: "User Management - Update User",
        user_management_create_user: "User Management - Create User"

    }
}
